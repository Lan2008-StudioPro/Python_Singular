'''
請寫出正確的程式
alist = [1, 2, 3]
blist = ["a", "b", "c"]
__(1)__
	print("alist 中的值等於 blist")
__(2)__
	print("alist 中的值不等於 blist")
	
(1), (2)該怎麼寫
'''