# 在下列的程式碼中:
aList = [0, 1, 2, 3, 4]
print(4 in aList)
'''
會輸出列印的內容?
( ) A.4
( ) B.5
( ) C.True
( ) D.False
'''
