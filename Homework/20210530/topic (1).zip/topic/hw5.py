'''
你為學校設計了一個Python應用程式,
在 classroom 的清單中包含了60位同學的姓名,
最後3名是班上的幹部。你需要分割清單內容顯示除了幹部以外的所有同學,
你可以利用以下哪二個程式碼達成?
( )A. classroom[0:-2]
( )B. classroom[0:-3]
( )C. classroom[1:-3]
( )D. classroom[:-3]
( )E. classroom[1:-3]
'''
