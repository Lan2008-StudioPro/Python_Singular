# 你為公司開發了一個Python應用程式, 設計了以下的程式
alist = ["a", "b", "c", "d", "e"]
blist = [1, 2, 3, 4, 5]
print(alist is blist)
print(alist == blist)
alist = blist
print(alist is blist)
print(alist == blist)
'''
根據程式碼片段中提供的資訊選擇每個問題的答案選項。
()(1)在第一次 print 後會顯示什麼? A.True B.False
()(2)在第二次 print 後會顯示什麼? A.True B.False
()(3)在第三次 print 後會顯示什麼? A.True B.False
()(4)在第四次 print 後會顯示什麼? A.True B.False
'''
